// Package jsonplan implements methods for outputting a plan in a
// machine-readable json format
package jsonplan
