No configs on purpose
